﻿/** Audit module interfaces */
export {};
