﻿/** Domains module interfaces */
export {};
