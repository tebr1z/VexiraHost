﻿/** Domains module types */
export {};
