﻿/** Licenses module types */
export {};
