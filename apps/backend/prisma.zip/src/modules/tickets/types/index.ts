﻿/** Tickets module types */
export {};
