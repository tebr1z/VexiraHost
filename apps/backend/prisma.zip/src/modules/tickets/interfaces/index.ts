﻿/** Tickets module interfaces */
export {};
