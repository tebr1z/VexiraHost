﻿/** Hosting module interfaces */
export {};
