﻿/** Admin module interfaces */
export {};
